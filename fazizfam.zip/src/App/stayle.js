import styled from "styled-components";
export const Container = styled.div`
width:100%;
height:920px;
background: linear-gradient(rgb(49, 49, 218),rgb(78, 223, 213));

`
export const ShoppingS = styled.div`
width:900px;
height:100px;
margin-left:auto;
margin-right:auto;
background-color:red;
padding-top:5px;
`
export const Kalendar = styled.div`
width:900px;
height:750px;
background-color:white;
margin-top:5px;
margin-left:auto;
margin-right:auto;

`
export const CartSOZ = styled.div`
width:200px;
height:50px;
margin-left:600px;
background-color:white;
border-radius:10px;
padding-left:20px;
cursor: pointer;
`
export const Cart = styled.h1`
color:red;
`
export const My = styled.h1`
color:red;
margin-left:50px;
padding-top:50px;
`
export const Velit = styled.h4`
margin-left:240px;
color:aqua;
`
export const Esse = styled.h4`
margin-left:241px;
margin-top:-20px;
`
export const Molistie = styled.h4`
margin-left:730px;
margin-top:-40px;
border: 5px solid aqua;
border-radius:50%;
font-size:15px;
text-align:center;
width:15px;
height:15px;
`
export const HR = styled.hr`
width:60%;
margin-left:230px;
opacity: 0.1;
`
export const BR = styled.div`
margin-top:140px;
`
export const Total = styled.h1`
font-size:30px;
color:aqua;
margin-left:50px;
margin-top:-50px;
`
export const Dollor = styled.span`
color:red;
`
export const Button = styled.button`
color:white;
padding:10px 35px;
backgrozund-color:red;
margin-left:680px;
margin-top:50px;
border:none;
`