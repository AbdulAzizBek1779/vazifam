import React from "react";
import { Container, ShoppingS, Kalendar, CartSOZ, Cart, My, Velit, Esse, Molistie, HR, BR, Total, Dollor, Button} from "../App/stayle";
class App extends React.Component {
  render() {
    return (
      <Container>
<ShoppingS>
  <CartSOZ>
    <Cart>Add To Cart</Cart>
  </CartSOZ>
</ShoppingS>
<Kalendar>
  <My>
    My Shopping bag (3)
  </My>
  <div>
    <div>
      <Velit>Velit Esse Molestie</Velit>
      <Esse>$ 30.00</Esse>
      <Molistie>x</Molistie>
    </div>
    <BR>
      <HR/>
      <Velit>Velit Esse Molestie</Velit>
      <Esse>$ 30.00</Esse>
      <Molistie>x</Molistie>
    </BR>
    <BR>
      <Velit>Velit Esse Molestie</Velit>
      <Esse>$ 30.00</Esse>
      <Molistie>x</Molistie>
    </BR>
  </div>
  <Button>Check Out</Button>
  <Total>Total : <Dollor>$65</Dollor></Total>
</Kalendar>
      </Container>
    )
  }
}
export default App;